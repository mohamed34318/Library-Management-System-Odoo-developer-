# -*- coding: utf-8 -*-
{
    'name': 'Library Management System',
    'version': '1.0.0',
    'category': 'Library',
    'author': 'IS Team',
    'sequence': 0,
    'summary': 'Library Management System',
    'description': """
   hello this system use to manage library where it can:
            1- add/delete/update/search book
""",
    'depends': ['mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/book_author.xml',
        'views/book_category.xml',
        'views/book_issue.xml',
        'views/book.xml',
        'views/menus.xml',
    ],
    'demo': [],
    'application': True,
    'auto_install': False,
}
