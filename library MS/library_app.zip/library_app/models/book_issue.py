from odoo import models, fields, api


class Issue(models.Model):
    _name = "book.issue"

    name = fields.Char(string='Name', required=True)
    description = fields.Text(string='Description')
