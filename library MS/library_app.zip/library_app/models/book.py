from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError, AccessError


class Book(models.Model):
    _name = "library.book"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "library book"

    name = fields.Char(string='Book Name', required=True, translate=True)
    code = fields.Integer(string='Book ID')
    image = fields.Binary('Book Image')
    category_id = fields.Many2one('book.category', string='Category', required=True)
    author_id = fields.Many2one('book.author', string='Author', required=True)
    date_publish = fields.Date(string="Publish Date")
    price = fields.Float(string='Price Of Book')
    description = fields.Text("About Book")
    active = fields.Boolean(string="Active", default=True)
    partner_id = fields.Many2one('res.partner', string='Borrower', tracking=1)
    issue_id = fields.Many2one('book.issue', string='Book Issue', tracking=1)
    state = fields.Selection([('available', 'Available'),
                              ('borrowed', 'Borrowed'),
                              ('lost', 'Lost'),
                              ('issue', 'Book Issue'), ],
                             string='State', default='available', tracking=1)

    def action_borrowed(self):
        if not self.partner_id:
            raise ValidationError('You have to select borrower first.')
        self.write({'state': 'borrowed'})

    def action_available(self):
        self.write({'state': 'available', 'partner_id': False, 'issue_id': False})

    def action_lost(self):
        self.write({'state': 'lost'})

    def action_issue(self):
        if not self.issue_id:
            raise ValidationError('You have to select book issue.')
        self.write({'state': 'issue'})

    # author_name = fields.Char(string='author name', required=True, translate=True)
    # Category = fields.Selection([('action', 'Action'), ('adventure', 'Adventure'), ('horror', 'Horror'), ('science', 'Science'),
    #                              ('classics', 'Classics'), ('crime', 'Crime'), ('romance', 'Romance'), ('war', 'War'), ('mystery', 'Mystery')],
    #                             string='category', default='action')
    # /reservations_id = fields.Many2one("books.reservations", string="reservations")

    # def _compute_age(self):
    #    pass
    # # write your idea code here
