from odoo import models, fields, api


class BookCategory(models.Model):
    _name = "book.category"

    name = fields.Char(string='Name', required=True)
    description = fields.Text(string='Description')
