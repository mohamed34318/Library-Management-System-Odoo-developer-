from odoo import models, fields, api


class Author(models.Model):
    _name = "book.author"

    name = fields.Char(string='Name', required=True)
    description = fields.Text(string='About Author')
